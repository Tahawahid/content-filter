<!-- Pre Loader Area start -->
<div id="preloader">
    <div id="preloader-status"><img src="{{ asset('assets/img/Logo-Gradiant-Reverse.png') }}" alt="img"></div>
</div>
<!-- Pre Loader Area End -->
