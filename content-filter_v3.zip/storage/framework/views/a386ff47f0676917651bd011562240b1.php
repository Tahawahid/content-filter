<?php if (isset($component)) { $__componentOriginal5d4d76fa7889a37ccf68bbd6a0f9c703 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d4d76fa7889a37ccf68bbd6a0f9c703 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.client.components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('c-head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d4d76fa7889a37ccf68bbd6a0f9c703)): ?>
<?php $attributes = $__attributesOriginal5d4d76fa7889a37ccf68bbd6a0f9c703; ?>
<?php unset($__attributesOriginal5d4d76fa7889a37ccf68bbd6a0f9c703); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d4d76fa7889a37ccf68bbd6a0f9c703)): ?>
<?php $component = $__componentOriginal5d4d76fa7889a37ccf68bbd6a0f9c703; ?>
<?php unset($__componentOriginal5d4d76fa7889a37ccf68bbd6a0f9c703); ?>
<?php endif; ?>

<body>
    
    <div class="container-fluid position-relative d-flex p-0">
        
        <?php if (isset($component)) { $__componentOriginal32092465d3097f808901497977e19ed7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32092465d3097f808901497977e19ed7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.client.components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('c-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32092465d3097f808901497977e19ed7)): ?>
<?php $attributes = $__attributesOriginal32092465d3097f808901497977e19ed7; ?>
<?php unset($__attributesOriginal32092465d3097f808901497977e19ed7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32092465d3097f808901497977e19ed7)): ?>
<?php $component = $__componentOriginal32092465d3097f808901497977e19ed7; ?>
<?php unset($__componentOriginal32092465d3097f808901497977e19ed7); ?>
<?php endif; ?>
        <div class="content">
            <?php if (isset($component)) { $__componentOriginal25eb3ea9918c1cd20278b617f652f522 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25eb3ea9918c1cd20278b617f652f522 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.client.components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('c-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25eb3ea9918c1cd20278b617f652f522)): ?>
<?php $attributes = $__attributesOriginal25eb3ea9918c1cd20278b617f652f522; ?>
<?php unset($__attributesOriginal25eb3ea9918c1cd20278b617f652f522); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25eb3ea9918c1cd20278b617f652f522)): ?>
<?php $component = $__componentOriginal25eb3ea9918c1cd20278b617f652f522; ?>
<?php unset($__componentOriginal25eb3ea9918c1cd20278b617f652f522); ?>
<?php endif; ?>
            <?php echo e($slot); ?>

            <?php if (isset($component)) { $__componentOriginalc292e305ac6f4ce65970051d1fd513ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc292e305ac6f4ce65970051d1fd513ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.client.components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('c-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc292e305ac6f4ce65970051d1fd513ce)): ?>
<?php $attributes = $__attributesOriginalc292e305ac6f4ce65970051d1fd513ce; ?>
<?php unset($__attributesOriginalc292e305ac6f4ce65970051d1fd513ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc292e305ac6f4ce65970051d1fd513ce)): ?>
<?php $component = $__componentOriginalc292e305ac6f4ce65970051d1fd513ce; ?>
<?php unset($__componentOriginalc292e305ac6f4ce65970051d1fd513ce); ?>
<?php endif; ?>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginalba0af19d000899d28394c5bb683adaa5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba0af19d000899d28394c5bb683adaa5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.client.components.foot','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('c-foot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba0af19d000899d28394c5bb683adaa5)): ?>
<?php $attributes = $__attributesOriginalba0af19d000899d28394c5bb683adaa5; ?>
<?php unset($__attributesOriginalba0af19d000899d28394c5bb683adaa5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba0af19d000899d28394c5bb683adaa5)): ?>
<?php $component = $__componentOriginalba0af19d000899d28394c5bb683adaa5; ?>
<?php unset($__componentOriginalba0af19d000899d28394c5bb683adaa5); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\client\components\layout.blade.php ENDPATH**/ ?>