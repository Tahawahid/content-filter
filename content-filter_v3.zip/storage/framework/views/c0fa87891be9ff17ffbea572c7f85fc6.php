<?php echo $__env->make('frontend.components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Begin Headless page -->
<div id="headless-wrapper">

    <!-- Sing In Area Start -->
    <section class="sign-up-page bg-secondary">

        <img src="<?php echo e(asset('assets/img/hero-floating-img.png')); ?>" alt="footer-bg"
            class="footer-floating-bg-img theme-common-floating-bg-img position-absolute img-fluid">

        <div class="container-fluid p-0">
            <div class="row sign-up-page-wrap-row justify-content-center">
                <div class="col-md-6">
                    <div class="sign-up-right-content position-relative bg-white radius-10">
                        <form action="<?php echo e(route('frontend.userLogin')); ?>" method="POST">

                            <?php echo csrf_field(); ?>
                            <div class="mb-25 sign-up-top-logo text-center">
                                <a href="/">
                                    <span class="logo-lg">
                                        <img src="<?php echo e(asset('assets/img/Logo-Gradiant-Reverse.png')); ?>" alt="">
                                    </span>
                                </a>
                            </div>

                            <h2 class="mb-25 font-bold">Log In</h2>

                            <p class="font-16 mb-30">Don’t have an account? <a href="<?php echo e(route('frontend.signUp')); ?>"
                                    class="color-hover font-medium">Sign up</a>
                            </p>
                            <div class="row mb-20">
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success"> <?php echo e(Session::get('success')); ?> </div>
                                <?php endif; ?>

                                <?php if(Session::has('error')): ?>
                                    <div class="alert alert-danger"> <?php echo e(Session::get('error')); ?> </div>
                                <?php endif; ?>
                            </div>
                            <div class="row mb-25">
                                <div class="col-md-12">
                                    <label class="label-text-title color-heading mb-2">Your Email</label>
                                    <input type="text" value="<?php echo e(old('email')); ?>" name="email" id="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="abraham@gmail.com">
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="invalid-feedback"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row mb-25">
                                <div class="col-md-12">
                                    <label class="label-text-title color-heading mb-2">Your Password</label>
                                    <div class="form-group mb-0 position-relative">
                                        <input class="form-control password <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="password" id="password" placeholder="Enter your password"
                                            type="password">
                                        <span class="toggle cursor fas fa-eye pass-icon"></span>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="invalid-feedback"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="row">
                                <div class="col-md-12 mb-25"><a href="account/forget-password"
                                        class="theme-link font-18 d-block text-start font-medium"
                                        title="Forgot password?">Forgot password?</a></div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <button type="submit" class="theme-btn font-15 fw-bold" title="Log In">Log
                                        In</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Sing In Area End -->

</div>
<!-- End Headless page -->


<?php if (isset($component)) { $__componentOriginal3256840aff405d62010313ad2de837cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3256840aff405d62010313ad2de837cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'frontend.components.foot','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('foot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3256840aff405d62010313ad2de837cf)): ?>
<?php $attributes = $__attributesOriginal3256840aff405d62010313ad2de837cf; ?>
<?php unset($__attributesOriginal3256840aff405d62010313ad2de837cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3256840aff405d62010313ad2de837cf)): ?>
<?php $component = $__componentOriginal3256840aff405d62010313ad2de837cf; ?>
<?php unset($__componentOriginal3256840aff405d62010313ad2de837cf); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views\frontend\sign-in.blade.php ENDPATH**/ ?>