<?php if (isset($component)) { $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">All Orders</h6>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-white">
                            <th scope="col">Date</th>
                            <th scope="col">Invoice</th>
                            <th scope="col">Customer</th>
                            <th scope="col">Phone</th>
                            
                            <th scope="col">Package</th>
                            <th scope="col">Tokens</th>
                            <th scope="col">Amount</th>
                            <th scope="col">Payment Receipt</th>
                            <th scope="col">Status</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->created_at->format('d M Y')); ?></td>
                                <td>ORD-<?php echo e($order->id); ?></td>
                                <td><?php echo e($order->userDetail->name ?? 'N/A'); ?></td>
                                <td><?php echo e($order->userDetail->phone_number); ?></td>
                                
                                <td><?php echo e($order->package->name); ?></td>
                                <td><?php echo e($order->tokens); ?></td>
                                <td>$<?php echo e($order->total); ?></td>
                                <td>
                                    <?php if($order['payment_receipt']): ?>
                                        <a href="<?php echo e(asset($order['payment_receipt'])); ?>" target="_blank"
                                            class="btn btn-sm btn-info">
                                            View Receipt
                                        </a>
                                    <?php else: ?>
                                        No Receipt
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <select class="form-select bg-dark text-white status-select"
                                        data-order-id="<?php echo e($order->id); ?>" onchange="updateStatus(this)">
                                        <option value="pending" <?php echo e($order->status === 'pending' ? 'selected' : ''); ?>>
                                            Pending</option>
                                        <option value="approved" <?php echo e($order->status === 'approved' ? 'selected' : ''); ?>>
                                            Approved</option>
                                        <option value="rejected" <?php echo e($order->status === 'rejected' ? 'selected' : ''); ?>>
                                            Rejected</option>
                                        <option value="on-hold" <?php echo e($order->status === 'on-hold' ? 'selected' : ''); ?>>
                                            On Hold</option>
                                        <option value="active" <?php echo e($order->status === 'active' ? 'selected' : ''); ?>>
                                            Active</option>
                                        <option value="cancelled"
                                            <?php echo e($order->status === 'cancelled' ? 'selected' : ''); ?>>
                                            Cancelled</option>
                                    </select>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('orders.show', $order->id)); ?>"
                                        class="btn btn-sm btn-info">View</a>
                                    
                                <td>
                                    <!-- Form to delete order -->
                                    <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST"
                                        style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"
                                            onclick="return confirm('Are you sure you want to delete this order?')">
                                            Delete
                                        </button>
                                    </form>
                                </td>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                <?php echo e($orders->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            function updateStatus(select) {
                const orderId = select.dataset.orderId;
                const status = select.value;

                fetch(`/admin/orders/${orderId}/status`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({
                            status
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            toastr.success('Order status updated successfully');
                        }
                    })
                    .catch(error => {
                        toastr.error('Failed to update order status');
                    });
            }

            function deleteOrder(orderId) {
                if (confirm('Are you sure you want to delete this order?')) {
                    fetch(`/admin/orders/${orderId}`, {
                            method: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                toastr.success('Order deleted successfully');
                                location.reload();
                            }
                        })
                        .catch(error => {
                            toastr.error('Failed to delete order');
                        });
                }
            }
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $attributes = $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $component = $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>


<script>
    function updateStatus(selectElement) {
        const orderId = selectElement.getAttribute('data-order-id');
        const selectedStatus = selectElement.value;

        fetch(`/account/admin/orders/${orderId}/status`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({
                    status: selectedStatus
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Status updated successfully');
                } else {
                    alert('Failed to update status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating status');
            });
    }
</script>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\admin\order\index.blade.php ENDPATH**/ ?>