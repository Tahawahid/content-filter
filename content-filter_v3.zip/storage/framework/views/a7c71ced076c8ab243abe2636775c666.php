<!-- Footer Start -->
<div class="container-fluid pt-4 px-4">
    <div class="bg-secondary rounded-top p-4">
        <div class="row">
            <div class="col-12">
                &copy; <a href="#">Content Filter AI</a>, All Right Reserved.
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\client\components\footer.blade.php ENDPATH**/ ?>