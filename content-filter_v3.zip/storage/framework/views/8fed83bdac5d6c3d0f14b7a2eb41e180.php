<?php if (isset($component)) { $__componentOriginal45d3b79719673a9a415ca2139a0c7693 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45d3b79719673a9a415ca2139a0c7693 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.client.components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('c-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="mb-0">Submit YouTube Link</h3>
                <a href="<?php echo e(route('content-filters.show', Auth::id())); ?>" class="btn btn-primary">
                    <i class="fas fa-list me-2"></i>See All Requests
                </a>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="bg-dark rounded p-4">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('content-filters.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-floating mb-3">
                                <input type="url" name="youtube_link"
                                    class="form-control <?php $__errorArgs = ['youtube_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="floatingYoutubeLink" placeholder="Paste YouTube link here"
                                    value="<?php echo e(old('youtube_link')); ?>" />
                                <label for="floatingYoutubeLink">YouTube Link</label>
                                <?php $__errorArgs = ['youtube_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-floating mb-4">
                                <select name="token_id" class="form-control <?php $__errorArgs = ['token_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="floatingTokens">
                                    <option value="">Select Package</option>
                                    <?php $__currentLoopData = $userTokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $token): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($token->id); ?>">
                                            <?php echo e($token->order->package->name); ?> - <?php echo e($token->remaining_tokens); ?> tokens
                                            remaining
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="floatingTokens">Select Package</label>
                                <?php $__errorArgs = ['token_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-primary py-3 w-100 mb-4">
                                Submit Link
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45d3b79719673a9a415ca2139a0c7693)): ?>
<?php $attributes = $__attributesOriginal45d3b79719673a9a415ca2139a0c7693; ?>
<?php unset($__attributesOriginal45d3b79719673a9a415ca2139a0c7693); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d3b79719673a9a415ca2139a0c7693)): ?>
<?php $component = $__componentOriginal45d3b79719673a9a415ca2139a0c7693; ?>
<?php unset($__componentOriginal45d3b79719673a9a415ca2139a0c7693); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\client\filter_request\index.blade.php ENDPATH**/ ?>