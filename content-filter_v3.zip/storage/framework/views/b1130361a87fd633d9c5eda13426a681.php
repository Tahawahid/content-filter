<?php if (isset($component)) { $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">All Packages</h6>
                <div>
                    <a href="<?php echo e(route('packages.create')); ?>" class="btn btn-sm btn-primary">Add Package</a>
                </div>

            </div>
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-white">
                            <th scope="col">
                                <input class="form-check-input" type="checkbox" />
                            </th>
                            <th scope="col">Date</th>
                            <th scope="col">Package Name</th>
                            <th scope="col">Token</th>
                            <th scope="col">Price</th>
                            <th scope="col">Features</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><input class="form-check-input" type="checkbox" /></td>
                                <td><?php echo e($package->created_at->format('d M Y')); ?></td>
                                <td><?php echo e($package->name); ?></td>
                                <td><?php echo e($package->token); ?></td>
                                <td>$<?php echo e(number_format($package->price, 2)); ?></td>
                                <td>
                                    <?php if(empty($package->features) || $package->features === 'null'): ?>
                                        No Features
                                    <?php else: ?>
                                        <?php echo e(is_array($package->features) ? implode(', ', $package->features) : $package->features); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('packages.edit', $package->id)); ?>"
                                        class="btn btn-sm btn-primary">Edit</a>
                                    <form action="<?php echo e(route('packages.destroy', $package->id)); ?>" method="POST"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"
                                            onclick="return confirm('Are you sure you want to delete this package?')">
                                            Remove
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">No packages found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $attributes = $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $component = $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\admin\package\index.blade.php ENDPATH**/ ?>