<?php if (isset($component)) { $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h6 class="mb-0">Request Details</h6>
                <a href="<?php echo e(route('filter.index')); ?>" class="btn btn-primary">Back to List</a>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <div class="bg-dark rounded p-4">
                        <form action="<?php echo e(route('filter.update', $request->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="mb-3">
                                <label class="form-label">User Name</label>
                                <input type="text" class="form-control" value="<?php echo e($request->user_name); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" value="<?php echo e($request->user_email); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">YouTube Link</label>
                                <input type="url" class="form-control" value="<?php echo e($request->youtube_link); ?>"
                                    readonly>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-control">
                                    <option value="pending" <?php echo e($request->status === 'pending' ? 'selected' : ''); ?>>
                                        Pending</option>
                                    <option value="processing"
                                        <?php echo e($request->status === 'processing' ? 'selected' : ''); ?>>Processing</option>
                                    <option value="approved" <?php echo e($request->status === 'approved' ? 'selected' : ''); ?>>
                                        Approved</option>
                                    <option value="rejected" <?php echo e($request->status === 'rejected' ? 'selected' : ''); ?>>
                                        Rejected</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Reason</label>
                                <textarea name="reason" class="form-control" rows="3"><?php echo e($request->reason); ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">Update Request</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $attributes = $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $component = $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\admin\filter\show.blade.php ENDPATH**/ ?>