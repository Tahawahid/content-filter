<?php if (isset($component)) { $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="mb-0">Order Details</h3>
                <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-primary">Back to Orders</a>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card bg-dark mb-4">
                        <div class="card-header">
                            <h5>Customer Information</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>Name:</strong> <?php echo e($order->userDetail->name ?? 'N/A'); ?></p>
                            <p><strong>Email:</strong> <?php echo e($order->userDetail->email ?? 'N/A'); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($order->userDetail->phone_number ?? 'N/A'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card bg-dark mb-4">
                        <div class="card-header">
                            <h5>Order Information</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>Order ID:</strong> #<?php echo e($order->id); ?></p>
                            <p><strong>Date:</strong> <?php echo e($order->created_at->format('d M Y')); ?></p>
                            <div class="mb-3">
                                <?php if($order['payment_receipt']): ?>
                                    <a href="<?php echo e(asset($order['payment_receipt'])); ?>" target="_blank"
                                        class="btn btn-sm btn-info">
                                        View Receipt
                                    </a>
                                <?php else: ?>
                                    No Receipt
                                <?php endif; ?>
                            </div>
                            <!-- Status Dropdown and Tokens/Price Inputs in the same form -->
                            <form action="<?php echo e(route('orders.update', $order->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="mb-3">
                                    <strong>Status:</strong>
                                    <select name="status" class="form-select form-select-sm">
                                        
                                        <option value="pending" <?php echo e($order->status === 'pending' ? 'selected' : ''); ?>>
                                            Pending</option>
                                        <option value="approved" <?php echo e($order->status === 'approved' ? 'selected' : ''); ?>>
                                            Approved</option>
                                        <option value="active" <?php echo e($order->status === 'active' ? 'selected' : ''); ?>>
                                            Active</option>
                                        <option value="rejected" <?php echo e($order->status === 'rejected' ? 'selected' : ''); ?>>
                                            Rejected</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <strong>Tokens:</strong>
                                    <input type="number" name="tokens"
                                        class="form-control form-control-sm border border-white"
                                        value="<?php echo e($order->tokens); ?>" min="1" required>
                                </div>

                                <div class="mb-3">
                                    <strong>Price:</strong>
                                    <input type="number" name="price"
                                        class="form-control form-control-sm border border-white"
                                        value="<?php echo e($order->total); ?>" min="0" step="0.01" required>
                                </div>


                                <button type="submit" class="btn btn-success btn-sm">Update</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card bg-dark">
                <div class="card-header">
                    <h5>Package Details</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table text-start align-middle table-bordered table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Package Name</th>
                                    <th>Tokens</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($order->package->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($order->package->token ?? 0); ?></td>
                                    <td>$<?php echo e($order->package->price ?? 0); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php if($order->status === 'pending'): ?>
                <div class="mt-4">
                    <form action="<?php echo e(route('orders.update', $order->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="status" value="active">
                        <button type="submit" class="btn btn-success">Approve Order</button>
                    </form>

                    <form action="<?php echo e(route('orders.update', $order->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="status" value="rejected">
                        <button type="submit" class="btn btn-danger ms-2">Reject Order</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $attributes = $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $component = $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\admin\order\show.blade.php ENDPATH**/ ?>