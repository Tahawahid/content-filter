<?php if (isset($component)) { $__componentOriginalda8d380e98119abf43af57aebe44cc7f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda8d380e98119abf43af57aebe44cc7f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda8d380e98119abf43af57aebe44cc7f)): ?>
<?php $attributes = $__attributesOriginalda8d380e98119abf43af57aebe44cc7f; ?>
<?php unset($__attributesOriginalda8d380e98119abf43af57aebe44cc7f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda8d380e98119abf43af57aebe44cc7f)): ?>
<?php $component = $__componentOriginalda8d380e98119abf43af57aebe44cc7f; ?>
<?php unset($__componentOriginalda8d380e98119abf43af57aebe44cc7f); ?>
<?php endif; ?>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        
        <?php if (isset($component)) { $__componentOriginal04aa6b020f97a81dfa7dbc31a643ad69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04aa6b020f97a81dfa7dbc31a643ad69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04aa6b020f97a81dfa7dbc31a643ad69)): ?>
<?php $attributes = $__attributesOriginal04aa6b020f97a81dfa7dbc31a643ad69; ?>
<?php unset($__attributesOriginal04aa6b020f97a81dfa7dbc31a643ad69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04aa6b020f97a81dfa7dbc31a643ad69)): ?>
<?php $component = $__componentOriginal04aa6b020f97a81dfa7dbc31a643ad69; ?>
<?php unset($__componentOriginal04aa6b020f97a81dfa7dbc31a643ad69); ?>
<?php endif; ?>
        <div class="content">
            <?php if (isset($component)) { $__componentOriginal8615a0a5f338a520d15786a38383222f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8615a0a5f338a520d15786a38383222f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8615a0a5f338a520d15786a38383222f)): ?>
<?php $attributes = $__attributesOriginal8615a0a5f338a520d15786a38383222f; ?>
<?php unset($__attributesOriginal8615a0a5f338a520d15786a38383222f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8615a0a5f338a520d15786a38383222f)): ?>
<?php $component = $__componentOriginal8615a0a5f338a520d15786a38383222f; ?>
<?php unset($__componentOriginal8615a0a5f338a520d15786a38383222f); ?>
<?php endif; ?>
            <?php echo e($slot); ?>

            <?php if (isset($component)) { $__componentOriginale0b9444e4608316a222c51a6de9693fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0b9444e4608316a222c51a6de9693fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0b9444e4608316a222c51a6de9693fd)): ?>
<?php $attributes = $__attributesOriginale0b9444e4608316a222c51a6de9693fd; ?>
<?php unset($__attributesOriginale0b9444e4608316a222c51a6de9693fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0b9444e4608316a222c51a6de9693fd)): ?>
<?php $component = $__componentOriginale0b9444e4608316a222c51a6de9693fd; ?>
<?php unset($__componentOriginale0b9444e4608316a222c51a6de9693fd); ?>
<?php endif; ?>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginala9e0c9f02baf2b1e0d3fdc050fab2ca2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9e0c9f02baf2b1e0d3fdc050fab2ca2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.foot','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-foot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9e0c9f02baf2b1e0d3fdc050fab2ca2)): ?>
<?php $attributes = $__attributesOriginala9e0c9f02baf2b1e0d3fdc050fab2ca2; ?>
<?php unset($__attributesOriginala9e0c9f02baf2b1e0d3fdc050fab2ca2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9e0c9f02baf2b1e0d3fdc050fab2ca2)): ?>
<?php $component = $__componentOriginala9e0c9f02baf2b1e0d3fdc050fab2ca2; ?>
<?php unset($__componentOriginala9e0c9f02baf2b1e0d3fdc050fab2ca2); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\admin\components\layout.blade.php ENDPATH**/ ?>