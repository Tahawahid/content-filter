<?php if (isset($component)) { $__componentOriginal0f509fab02c45445826003a1e50db506 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f509fab02c45445826003a1e50db506 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'frontend.components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $attributes = $__attributesOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__attributesOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $component = $__componentOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__componentOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>

<!-- Begin Headless page -->
<div id="headless-wrapper">

    <!-- Sing In Area Start -->
    <section class="sign-up-page bg-secondary">

        <img src="assets/img/hero-floating-img.png" alt="footer-bg"
            class="footer-floating-bg-img theme-common-floating-bg-img position-absolute img-fluid">

        <div class="container-fluid p-0">
            <div class="row sign-up-page-wrap-row justify-content-center">
                <div class="col-md-6">
                    <div class="sign-up-right-content position-relative bg-white radius-10">
                        <form>

                            <div class="mb-25 sign-up-top-logo text-center">
                                <a href="/">
                                    <span class="logo-lg">
                                        <img src="assets/img/logo-dark.png" alt="">
                                    </span>
                                </a>
                            </div>

                            <h2 class="mb-25 font-bold">Forgot Password</h2>
                            <div class="row mb-25">
                                <div class="col-md-12">
                                    <label class="label-text-title color-heading mb-2">Your Email</label>
                                    <input type="text" class="form-control" placeholder="abraham@gmail.com">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <button type="button" class="theme-btn font-15 fw-bold"
                                        title="Send">Send</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Sing In Area End -->

</div>
<!-- End Headless page -->

<?php if (isset($component)) { $__componentOriginal3256840aff405d62010313ad2de837cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3256840aff405d62010313ad2de837cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'frontend.components.foot','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('foot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3256840aff405d62010313ad2de837cf)): ?>
<?php $attributes = $__attributesOriginal3256840aff405d62010313ad2de837cf; ?>
<?php unset($__attributesOriginal3256840aff405d62010313ad2de837cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3256840aff405d62010313ad2de837cf)): ?>
<?php $component = $__componentOriginal3256840aff405d62010313ad2de837cf; ?>
<?php unset($__componentOriginal3256840aff405d62010313ad2de837cf); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views\frontend\forget-password.blade.php ENDPATH**/ ?>