<?php if (isset($component)) { $__componentOriginal45d3b79719673a9a415ca2139a0c7693 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45d3b79719673a9a415ca2139a0c7693 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.client.components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('c-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <!-- Remaining Tokens -->
            <?php if($user_tokens > 0): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-2">
                        <i class="fa fa-coins fa-3x text-primary"></i>
                        <div class="ms-3">
                            <p class="mb-2">Remaining Tokens</p>
                            <h6 class="mb-0"><?php echo e($user_tokens ?? '0'); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Total Subscriptions -->
            <?php if(array_sum($status_counts) > 0): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-2">
                        <i class="fa fa-chart-pie fa-3x text-info"></i>
                        <div class="ms-3">
                            <p class="mb-2">Total Subscriptions</p>
                            <h6 class="mb-0"><?php echo e(array_sum($status_counts)); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Active Subscriptions -->
            <?php if(isset($status_counts['active']) && $status_counts['active'] > 0): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-2">
                        <i class="fa fa-check-circle fa-3x text-success"></i>
                        <div class="ms-3">
                            <p class="mb-2">Active Subscriptions</p>
                            <h6 class="mb-0"><?php echo e($status_counts['active'] ?? '0'); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Pending Subscriptions -->
            <?php if(isset($status_counts['pending']) && $status_counts['pending'] > 0): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-2">
                        <i class="fa fa-clock fa-3x text-warning"></i>
                        <div class="ms-3">
                            <p class="mb-2">Pending Subscriptions</p>
                            <h6 class="mb-0"><?php echo e($status_counts['pending'] ?? '0'); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Approved Subscriptions -->
            <?php if(isset($status_counts['approved']) && $status_counts['approved'] > 0): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-2">
                        <i class="fa fa-thumbs-up fa-3x text-success"></i>
                        <div class="ms-3">
                            <p class="mb-2">Approved Subscriptions</p>
                            <h6 class="mb-0"><?php echo e($status_counts['approved'] ?? '0'); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Rejected Subscriptions -->
            <?php if(isset($status_counts['rejected']) && $status_counts['rejected'] > 0): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-2">
                        <i class="fa fa-times-circle fa-3x text-danger"></i>
                        <div class="ms-3">
                            <p class="mb-2">Rejected Subscriptions</p>
                            <h6 class="mb-0"><?php echo e($status_counts['rejected'] ?? '0'); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Cancelled Subscriptions -->
            <?php if(isset($status_counts['cancelled']) && $status_counts['cancelled'] > 0): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-2">
                        <i class="fa-solid fa-ban fa-3x text-dark"></i>
                        <div class="ms-3">
                            <p class="mb-2">Cancelled Subscriptions</p>
                            <h6 class="mb-0"><?php echo e($status_counts['cancelled'] ?? '0'); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- On-Hold Subscriptions -->
            <?php if(isset($status_counts['on-hold']) && $status_counts['on-hold'] > 0): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-2">
                        <i class="fa fa-pause-circle fa-3x text-info"></i>
                        <div class="ms-3">
                            <p class="mb-2">On-Hold Subscriptions</p>
                            <h6 class="mb-0"><?php echo e($status_counts['on-hold'] ?? '0'); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-5 shadow-lg">
            <?php if($active_subscriptions->isNotEmpty()): ?>
                <div class="text-center">
                    <i class="fa fa-check-circle fa-4x text-success mb-4"></i>
                    <h3 class="text-success">Your Active Subscriptions</h3>

                    <div class="row mt-4">
                        <?php $__currentLoopData = $active_subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4">
                                <div class="card bg-dark text-white p-3 shadow-sm">
                                    <h5 class="text-primary">Package: <?php echo e($subscription->package->name); ?></h5>
                                    <p>Price: <strong>$<?php echo e(number_format($subscription->price, 2)); ?></strong></p>
                                    <p>Tokens: <strong><?php echo e($subscription->tokens); ?></strong></p>
                                    <p>Remaining Tokens:
                                        <strong><?php echo e($subscription->userToken->remaining_tokens ?? '0'); ?></strong>
                                    </p>
                                    <p>Purchase Date: <strong><?php echo e($subscription->created_at->format('Y-m-d')); ?></strong>
                                    </p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="text-center">
                    <i class="fa fa-info-circle fa-4x text-primary mb-4"></i>
                    <h3 class="text-primary">No Active Subscription</h3>
                    <p class="text-white-50">Explore our packages to access exclusive features. Contact us if you need
                        assistance!</p>

                    <div class="mt-4">
                        <a href="<?php echo e(route('frontend.home')); ?>#pricing" class="btn btn-primary btn-lg me-2">View
                            Packages</a>
                        <a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-outline-primary btn-lg">Contact Us</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-5 shadow-lg">
            <?php if($pending_subscriptions->isNotEmpty()): ?>
                <div class="text-center">
                    <i class="fa fa-clock fa-4x text-warning mb-4"></i>
                    <h3 class="text-warning">Your Pending Subscriptions</h3>

                    <div class="row mt-4">
                        <?php $__currentLoopData = $pending_subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4">
                                <div class="card bg-dark text-white p-3 shadow-sm">
                                    <h5 class="text-warning">Package: <?php echo e($subscription->package->name); ?></h5>
                                    <p>Price: <strong>$<?php echo e(number_format($subscription->price, 2)); ?></strong></p>
                                    <p>Tokens: <strong><?php echo e($subscription->tokens); ?></strong></p>
                                    <p>Status: <span class="badge bg-warning">Pending</span></p>
                                    <p>Submitted Date:
                                        <strong><?php echo e($subscription->created_at->format('Y-m-d')); ?></strong>
                                    </p>
                                    <a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-warning mt-2">
                                        <i class="fa fa-question-circle me-2"></i>Inquire About Package
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-5 shadow-lg">
            <?php if(isset($status_counts['approved']) && $status_counts['approved'] > 0): ?>
                <div class="text-center">
                    <i class="fa fa-thumbs-up fa-4x text-success mb-4"></i>
                    <h3 class="text-success">Your Approved Subscriptions</h3>

                    <div class="row mt-4">
                        <?php $__currentLoopData = $approved_subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4">
                                <div class="card bg-dark text-white p-3 shadow-sm">
                                    <h5 class="text-success">Package: <?php echo e($subscription->package->name); ?></h5>
                                    <p>Price: <strong>$<?php echo e(number_format($subscription->price, 2)); ?></strong></p>
                                    <p>Tokens: <strong><?php echo e($subscription->tokens); ?></strong></p>
                                    <p>Status: <span class="badge bg-success">Approved</span></p>
                                    <p>Approval Date: <strong><?php echo e($subscription->updated_at->format('Y-m-d')); ?></strong>
                                    </p>
                                    <a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-primary mt-2">
                                        <i class="fa fa-question-circle me-2"></i>Inquire About Package
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- On-Hold Subscriptions Section -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-5 shadow-lg">
            <?php if(isset($status_counts['on-hold']) && $status_counts['on-hold'] > 0): ?>
                <div class="text-center">
                    <i class="fa fa-pause-circle fa-4x text-info mb-4"></i>
                    <h3 class="text-info">Your On-Hold Subscriptions</h3>

                    <div class="row mt-4">
                        <?php $__currentLoopData = $onhold_subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4">
                                <div class="card bg-dark text-white p-3 shadow-sm">
                                    <h5 class="text-info">Package: <?php echo e($subscription->package->name); ?></h5>
                                    <p>Price: <strong>$<?php echo e(number_format($subscription->price, 2)); ?></strong></p>
                                    <p>Tokens: <strong><?php echo e($subscription->tokens); ?></strong></p>
                                    <p>Status: <span class="badge bg-info">On Hold</span></p>
                                    <p>Hold Date: <strong><?php echo e($subscription->updated_at->format('Y-m-d')); ?></strong></p>
                                    <a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-info mt-2">Inqure
                                        About Package</a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Cancelled Subscriptions Section -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-5 shadow-lg">
            <?php if(isset($status_counts['cancelled']) && $status_counts['cancelled'] > 0): ?>
                <div class="text-center">
                    <i class="fa fa-times-circle fa-4x text-light mb-4"></i>
                    <h3 class="text-light">Your Cancelled Subscriptions</h3>

                    <div class="row mt-4">
                        <?php $__currentLoopData = $cancelled_subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4">
                                <div class="card bg-dark text-white p-3 shadow-sm">
                                    <h5 class="text-light">Package: <?php echo e($subscription->package->name); ?></h5>
                                    <p>Price: <strong>$<?php echo e(number_format($subscription->price, 2)); ?></strong></p>
                                    <p>Tokens: <strong><?php echo e($subscription->tokens); ?></strong></p>
                                    <p>Status: <span class="badge bg-dark">Cancelled</span></p>
                                    <p>Cancellation Date:
                                        <strong><?php echo e($subscription->updated_at->format('Y-m-d')); ?></strong>
                                    </p>
                                    <a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-light mt-2">Inqure
                                        About Package</a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-5 shadow-lg">
            <?php if(isset($status_counts['cancelled']) && $status_counts['cancelled'] > 0): ?>
                <div class="text-center">
                    <i class="fa fa-times-circle fa-4x text-danger mb-4"></i>
                    <h3 class="text-danger">Your Rejected Subscriptions</h3>

                    <div class="row mt-4">
                        <?php $__currentLoopData = $rejected_subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-4">
                                <div class="card bg-dark text-white p-3 shadow-sm">
                                    <h5 class="text-danger">Package: <?php echo e($subscription->package->name); ?></h5>
                                    <p>Price: <strong>$<?php echo e(number_format($subscription->price, 2)); ?></strong></p>
                                    <p>Tokens: <strong><?php echo e($subscription->tokens); ?></strong></p>
                                    <p>Status: <span class="badge bg-dark">Cancelled</span></p>
                                    <p>Cancellation Date:
                                        <strong><?php echo e($subscription->updated_at->format('Y-m-d')); ?></strong>
                                    </p>
                                    <a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-danger mt-2">
                                        <i class="fa fa-question-circle me-2"></i>Contact Support
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45d3b79719673a9a415ca2139a0c7693)): ?>
<?php $attributes = $__attributesOriginal45d3b79719673a9a415ca2139a0c7693; ?>
<?php unset($__attributesOriginal45d3b79719673a9a415ca2139a0c7693); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d3b79719673a9a415ca2139a0c7693)): ?>
<?php $component = $__componentOriginal45d3b79719673a9a415ca2139a0c7693; ?>
<?php unset($__componentOriginal45d3b79719673a9a415ca2139a0c7693); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\client\home.blade.php ENDPATH**/ ?>