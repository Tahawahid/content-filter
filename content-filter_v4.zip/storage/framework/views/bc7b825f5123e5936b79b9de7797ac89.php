<!-- Pre Loader Area start -->
<div id="preloader">
    <div id="preloader-status"><img src="<?php echo e(asset('assets/img/Logo-Gradiant-Reverse.png')); ?>" alt="img"></div>
</div>
<!-- Pre Loader Area End -->
<?php /**PATH E:\laravel\content-filter\resources\views\frontend\components\preloader.blade.php ENDPATH**/ ?>