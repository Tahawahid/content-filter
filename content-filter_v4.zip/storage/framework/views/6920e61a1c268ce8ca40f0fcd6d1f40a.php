<?php if (isset($component)) { $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.admin.components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('d-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-4">
            <h3 class="mb-4">Add New Admin</h3>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label class="form-label">Admin Name</label>
                    <input type="text" name="name" class="form-control bg-dark text-white" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control bg-dark text-white" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control bg-dark text-white" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control bg-dark text-white"
                        required>
                </div>

                <button type="submit" class="btn btn-primary">Create Admin</button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $attributes = $__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__attributesOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3)): ?>
<?php $component = $__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3; ?>
<?php unset($__componentOriginalb43ce21c4b1b57e51159c89a887b1ad3); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views\dashboard\admin\AdminCreate.blade.php ENDPATH**/ ?>