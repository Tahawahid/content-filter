<?php if (isset($component)) { $__componentOriginal45d3b79719673a9a415ca2139a0c7693 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45d3b79719673a9a415ca2139a0c7693 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dashboard.client.components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('c-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="mb-0">Your Filter Requests</h3>
            </div>

            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr>
                            <th scope="col" class="text-white">Date</th>
                            <th scope="col" class="text-white">YouTube Link</th>
                            <th scope="col" class="text-white">Status</th>
                            <th scope="col" class="text-white">Token Cost</th>
                            <th scope="col" class="text-white">Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $filterRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($request->created_at->format('d M Y')); ?></td>
                                <td>
                                    <a href="<?php echo e($request->youtube_link); ?>" target="_blank" class="text-primary">
                                        <?php echo e(Str::limit($request->youtube_link, 30)); ?>

                                    </a>
                                </td>
                                <td>
                                    <span
                                        class="badge bg-<?php echo e($request->status === 'approved' ? 'success' : ($request->status === 'pending' ? 'warning' : 'danger')); ?>">
                                        <?php echo e(ucfirst($request->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($request->token_cost); ?> tokens</td>
                                <td><?php echo e($request->reason ?? 'N/A'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="mt-4 d-flex justify-content-center">
                    <?php echo e($filterRequests->links('vendor.pagination.bootstrap-5')); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45d3b79719673a9a415ca2139a0c7693)): ?>
<?php $attributes = $__attributesOriginal45d3b79719673a9a415ca2139a0c7693; ?>
<?php unset($__attributesOriginal45d3b79719673a9a415ca2139a0c7693); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d3b79719673a9a415ca2139a0c7693)): ?>
<?php $component = $__componentOriginal45d3b79719673a9a415ca2139a0c7693; ?>
<?php unset($__componentOriginal45d3b79719673a9a415ca2139a0c7693); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\content-filter\resources\views/dashboard/client/filter_request/show.blade.php ENDPATH**/ ?>