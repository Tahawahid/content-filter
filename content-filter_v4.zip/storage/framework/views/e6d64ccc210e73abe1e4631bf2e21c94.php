



<div class="cart-sidebar" id="cartSidebar">
    <div class="cart-header">
        <h4>Shopping Cart</h4>
        <button class="close-cart" onclick="toggleCart()">×</button>
    </div>
    <div class="cart-items">
        <?php if(session('cart') && count(session('cart')) > 0): ?>
            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cart-item" data-id="<?php echo e($id); ?>">
                    <div class="item-details">
                        <h5><?php echo e($details['name']); ?></h5>
                        <p>$<?php echo e($details['price']); ?></p>
                        <button class="remove-btn" onclick="removeItem('<?php echo e($id); ?>')">Remove</button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="cart-total">
                <h5>Total: $<?php echo e(session('cart_total') ?? 0); ?></h5>
                <a href="<?php echo e(route('cart.index')); ?>" class="theme-btn w-100">View Cart</a>
            </div>
        <?php else: ?>
            <p>Your cart is empty</p>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH E:\laravel\content-filter\resources\views\frontend\components\cartbar.blade.php ENDPATH**/ ?>