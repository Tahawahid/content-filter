<!DOCTYPE html>
<html lang="en">

@include('frontend.components.head')

<body class="home-2">
    {{ $slot }}
    @include('frontend.components.foot')
</body>

</html>
